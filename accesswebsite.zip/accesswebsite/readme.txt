=== Access website ===
Contributors: buburok
Donate link: https://websitepr.eu/
Tags: keep all web site accesses, site accesses, Easily save all web site accesses,Save and save all the accesses you need for one or multiple sites and easily manage them
Requires at least: 5.0
Tested up to: 5.0
Stable tag: 5.0
Requires PHP: 7.0
License: 
License URI: https://websitepr.eu/baneri-site/accesswebsite.zip

Easily save all web site accesses.

== Description ==

Save and save all the accesses you need for one or multiple sites and easily manage them, save for each website you have: site, site login, site username, site password, ftp, ftp username, ftp password, C-panel, C-panel username, C-panel password, Hosting url, hosting username, hosting password

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Access website in dashboard 



== Frequently Asked Questions ==

= A question that someone might have =

Easily save all web site accesses.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

1. This screen shot:

== Changelog ==

= 5.0 =
* A change since the previous version.
* Another change.

= 5.0 =
* List versions from most recent at top to oldest at bottom.

== Upgrade Notice ==

= 5.0 =
Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.

= 5.0 =
This version fixes a security related bug.  Upgrade immediately.

== Arbitrary section ==

You may provide arbitrary sections, in the same format as the ones above.  This may be of use for extremely complicated
plugins where more information needs to be conveyed that doesn't fit into the categories of "description" or
"installation."  Arbitrary sections will be shown below the built-in sections outlined above.

== A brief Markdown Example ==

